package com.ParcialProgramacionMovil.ProgramacionMovilP.iservice;

import com.ParcialProgramacionMovil.ProgramacionMovilP.entity.Tables;

public interface ITablesService extends IBaseService<Tables> {
    // Aquí puedes agregar métodos específicos para la entidad Tables si es necesario
    // Por ejemplo:
    // List<Tables> findBySomeCriteria(String criteria);
}
