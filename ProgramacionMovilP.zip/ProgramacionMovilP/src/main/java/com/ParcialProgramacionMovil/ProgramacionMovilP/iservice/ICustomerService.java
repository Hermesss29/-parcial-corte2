package com.ParcialProgramacionMovil.ProgramacionMovilP.iservice;

import com.ParcialProgramacionMovil.ProgramacionMovilP.entity.Customer;


public interface ICustomerService extends IBaseService<Customer>{
}